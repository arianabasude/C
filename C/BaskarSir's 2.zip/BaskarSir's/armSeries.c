#include<stdio.h>
int main(){
	int i,temp,ans,arm,length,r,j;
	
	
	for(i=150;i<=152;i++){
		temp=i;
		length=0;
		arm=0;
		while(temp!=0){
			temp=temp/10;
			length++;
			
		}
		printf("%d\n",length);
		temp=i;
		//printf("%d",temp);
		
		while(temp!=0){
		r=temp%10;
		ans=1;
		printf("%d\n",length);
		for(j=1;j<=length;j++){
			ans=ans*r;
			
		}

		//arm=arm+ans;
		//printf("%d",arm);
		
	}
	/*
	if(i==arm){
		printf("arm:%d\n",i);
	}
	*/

	}
	return 10;}
	
/*
Enter num34
Sum:7
*/