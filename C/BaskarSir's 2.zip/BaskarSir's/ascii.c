#include<stdio.h>
int main(){
	int i;
	for(i=0;i<=127;i++){
		printf("%d:%c\n",i,i);
	}

	return 10;
	}
	