#include<stdio.h>
int main(){
	int i,n;
	printf("Enter n:");
	scanf("%d",&n);
	printf("first %d natural numbers\n",n);
	for(i=1;i<=n;i++){
		printf("%d\n",i);

	}
}
/*
Enter n:10
first 10 natural numbers
1
2
3
4
5
6
7
8
9
10


*/