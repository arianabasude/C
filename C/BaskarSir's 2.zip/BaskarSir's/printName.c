#include<stdio.h>
int main(){
	int i;
	char name[20];
	printf("Enter your name:");
	scanf("%s",name);
	for(i=1;i<6;i++){
		printf("%s\n",name);

	}
}
/*

Enter your name:Gayatri
Gayatri
Gayatri
Gayatri
Gayatri
Gayatri

*/