#include<stdio.h>
int main(){
	int num;
	printf("Enter num:");
	scanf("%d",&num);
	num%2==0? printf("Even"):printf("odd");

	return 10;
}